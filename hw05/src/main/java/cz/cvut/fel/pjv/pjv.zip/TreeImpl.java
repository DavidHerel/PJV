/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.fel.pjv;

/**
 *
 * @author fuji
 */
public class TreeImpl implements Tree {
    int[] values;
    Node root;
    int start;
    int end;
    int depth;
    int right;
    int left;
    
    @Override
    public void setTree(int[] values) {
        this.values = values;
        root = makeTree(0, values.length, values);
    }

    private Node makeTree(int start, int end, int[] values) {
        if ((start >= end)){
            return null;
        }
        NodeImpl node = new NodeImpl();
        int mid = ((start+end)/2);
        node.setValue(values[mid]);
        node.setLeft(makeTree(start, mid, values));      
        node.setRight(makeTree(mid+1, end, values));   
        return node;
               
    }

    @Override
    public Node getRoot() {
        return root;
    }
    
    @Override
    public String toString(){
        String tree = "";
        depth = 0;
        return makeString(tree, depth, root);
    }
    
    public String makeString(String tree, int depth, Node node){
        if (node == null){
            return "";
        }
        tree = "";
        for (int i = 0; i < depth; i++){
            tree += " ";
        }
        tree += "- " + node.getValue() + "\n";
        if (node.getLeft() != null){
            tree += makeString(tree, depth+1, node.getLeft());
        }
        if (node.getRight() != null){
           tree += makeString(tree, depth+1, node.getRight()); 
        }        
        return tree;
    }
}
